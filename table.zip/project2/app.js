let table = document.getElementById('table');
fetch('project.json')
    .then(res => res.json())
    .then(data => makeTable(data));


function makeTable(json) {
    let Data = json.feed.entry;
    $('#table').DataTable({
        data: Data,
        columns: [
            { data: 'ticket' },
            { data: 'opendate' },
            { data: 'symbol' },
            { data: 'action' },
            { data: "unitslots" },
            { data: "openprice" },
            { data: "sl" },
            { data: "tp" },
            { data: "closedate" },
            { data: "closeprice" },
            { data: "commission" },
            { data: "swap" },
            { data: "sl" }
        ],
        initComplete: function() {
            $('div.dataTables_length').addClass('demo');
            $('div.dataTables_filter').addClass('demo');
        }
    });
    
    const inp = document.getElementsByTagName('input');
    inp[0].placeholder =  "Search..."    
    const lb = document.getElementsByTagName('label');
    lb[0] = '';

}